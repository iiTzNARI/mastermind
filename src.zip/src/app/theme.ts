// "use client";
// import { defineConfig, createSystem } from "@chakra-ui/react";

// const config = defineConfig({
//   theme: {
//     tokens: {
//       colors: {
//         brand: {
//           50: { value: "#e0e7ff" },
//           100: { value: "#c7d2fe" },
//           200: { value: "#a5b4fc" },
//           300: { value: "#818cf8" },
//           400: { value: "#6366f1" },
//           500: { value: "#4f46e5" },
//           600: { value: "#4338ca" },
//           700: { value: "#3730a3" },
//           800: { value: "#312e81" },
//           900: { value: "#1e1b4b" },
//         },
//       },
//     },
//     semanticTokens: {
//       colors: {
//         danger: { value: "{colors.brand.500}" }, // トークン参照
//       },
//     },
//     breakpoints: {
//       sm: "320px",
//       md: "768px",
//       lg: "960px",
//       xl: "1200px",
//     },
//     keyframes: {
//       spin: {
//         from: { transform: "rotate(0deg)" },
//         to: { transform: "rotate(360deg)" },
//       },
//     },
//   },
// });

// const system = createSystem(config);

// export default system;
